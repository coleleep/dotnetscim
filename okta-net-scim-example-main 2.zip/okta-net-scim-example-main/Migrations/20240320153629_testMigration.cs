﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace okta_scim_server_dotnet.Migrations
{
    /// <inheritdoc />
    public partial class testMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Groups",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    DisplayName = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Groups", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Members",
                columns: table => new
                {
                    Value = table.Column<string>(type: "TEXT", nullable: false),
                    Display = table.Column<string>(type: "TEXT", nullable: false),
                    GroupsId = table.Column<int>(type: "INTEGER", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Members", x => x.Value);
                    table.ForeignKey(
                        name: "FK_Members_Groups_GroupsId",
                        column: x => x.GroupsId,
                        principalTable: "Groups",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "Groups",
                columns: new[] { "Id", "DisplayName" },
                values: new object[] { 1, "scimGroup" });

            migrationBuilder.InsertData(
                table: "Members",
                columns: new[] { "Value", "Display", "GroupsId" },
                values: new object[] { "1", "mdaldo@fake.domain", null });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Active", "DisplayName", "ExternalId", "FirstName", "LastName", "MiddleName", "UserName" },
                values: new object[] { 4, true, "Bob Loblaw", null, "Bob", "Loblaw", null, "blob@loblaw.domain" });

            migrationBuilder.CreateIndex(
                name: "IX_Members_GroupsId",
                table: "Members",
                column: "GroupsId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Members");

            migrationBuilder.DropTable(
                name: "Groups");

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
